﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CeUAA14Partie2_dec23_Ramsamy_Ewan
{
    internal class PaintBallGun //Attributs privés du "PaintBallGun"
    {
        private int _poche;
        private int _chargeur;
        
        public PaintBallGun(int poche, int chargeur) //Création du "PaintBallGun"
        {
            _poche = poche;
            _chargeur = chargeur;
        }

        public int Poche //Créé pour pouvoir modifier et afficher la poche
        {
            get { return _poche; }
            set { _poche = value; }
        }

        public int Chargeur //Créé pour pouvoir modifier et afficher le chargeur
        {
            get { return _chargeur; }
            set { _chargeur = value; }
        }

        public string Caracteristiques() //Méthode pour reprendre le nombre de balles dans la poche et le chargeur
        {
            string chaine = "Vous avez un total de " + _poche + " balles dans votre poche, et " + _chargeur + " dans votre chargeur";
            return chaine;
        }

        public string Tirer() //Méthode pour tire une balle, si on le peut
        {
            string chaine = " ";
            if (_chargeur == 0)
            {
                chaine = "Vous n'avez pas assez de balle dans votre chargeur pour tirer";
            }
            else
            {
                chaine = "=> Tir effectué !";
            }
            return chaine;
        }
        public string Recharger() //Méthode pour recharger, si on le peut et que le chargeur est bien vide
        {
            string chaine = " ";
            if (_chargeur > 0)
            {
                chaine = "Il faut que votre chargeur soit vide afin de le recharger";
            }
            else if (_poche < 16)
            {
                chaine = "Vous n'avez pas assez de balles dans votre poche";
            }
            else
            {
                chaine = "=> Recharge de 16 balles dans le chargeur effectuée";
            }
            return chaine;
        }
        public string ReprendreMunitions() //Méthode pour reprendre 30 munitions
        {
            string chaine = "Vous avez repris 30 balles, que vous avez rangées dans votre poche";
            return chaine;
        }
        public string MauvaisChoix() //Méthode pour si l'utilisateur tape autre chose que ce qui est demandé
        {
            string chaine = "La commande que vous venez d'effectué n'est pas prise en compte, veuillez réessayer";
            return chaine;
        }
        public string AuRevoir() //Méthode, qui ne sera sûrement pas lue par l'utilisateur, le remerciant d'avoir joué, en lui souhaitant une bonne journée
        {
            string chaine = "Merci d'avoir utilisé l'application, à bientôt";
            return chaine;
        }
    }
}