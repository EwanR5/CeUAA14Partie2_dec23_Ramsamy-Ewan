﻿namespace CeUAA14Partie2_dec23_Ramsamy_Ewan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenue dans ce jeu de tir ... Vous démarrez avec 30 balles \n=============================================================");
            PaintBallGun PaintBallGun1 = new PaintBallGun(30, 0); //Création du "PaintBallGun numéro 1"

            string choix = "";
            do // Boucle qui ^relance tout jusqu'à ce que l'utilisateur tape "q"
            {
                Console.WriteLine(PaintBallGun1.Caracteristiques()); //Affiche le nombre de balles dans la poche et le chargeur
                if (PaintBallGun1.Chargeur == 0) //Affiche le message seulement si le chargeur est vide
                {
                    Console.WriteLine("Attention, votre chargeur est vide");
                }

                Console.WriteLine("\nEspace pour tirer, \nr pour recharger, \n+ pour reprendre des munitions, \nq pour quitter"); //Demande de faire un choix à l'utilisateur, bien qu'il ne puisse pas tirer
                choix = Console.ReadLine();

                if (choix == " ")
                {
                    Console.WriteLine(PaintBallGun1.Tirer()); //Diminue de 1 les balles dans le chargeur, sauf si elles sont déjà à 0
                    Console.ReadLine();
                    if (PaintBallGun1.Chargeur > 0)
                    {
                        PaintBallGun1.Chargeur = PaintBallGun1.Chargeur - 1;
                    }
                }
                else if (choix == "r")
                {
                    Console.WriteLine(PaintBallGun1.Recharger()); //Recharge le chargeur seulement s'il n'y a plus rien dedans et qu'on a assez de balles dans la poche
                    Console.ReadLine();
                    if (PaintBallGun1.Chargeur == 0 && PaintBallGun1.Poche >= 16)
                    {
                        PaintBallGun1.Poche = PaintBallGun1.Poche - 16;
                        PaintBallGun1.Chargeur = 16;
                    }
                }
                else if (choix == "+")
                {
                    Console.WriteLine(PaintBallGun1.ReprendreMunitions()); //Ajoute 30 balles à la poche
                    Console.ReadLine();
                    PaintBallGun1.Poche = PaintBallGun1.Poche + 30;
                }
                else if (choix == "q")
                {
                    Console.WriteLine(PaintBallGun1.AuRevoir()); //Dit Au revoir à l'utilisateur, avant de fermer l'appli
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine(PaintBallGun1.MauvaisChoix()); //Anonce à l'utilisateur qu'il n'a pas taper quelque chose de pris en compte
                    Console.ReadLine();
                }
            } while (choix != "q"); //Ferme l'applis si "q" est tapé dans les choix
        }
    }
}